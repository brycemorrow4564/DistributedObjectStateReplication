package a1.common;

import a1.client.NIOClientCommunicator;
import util.interactiveMethodInvocation.IPCMechanism;

public interface InitialConfigurations {
	
	public void setupInitialConfigurations(); 
	
	public static enum BroadcastMode { LOCAL, NON_ATOMIC, ATOMIC };
	public static BroadcastMode broadcastMode = BroadcastMode.NON_ATOMIC; 
	public static IPCMechanism ipcMechanism = IPCMechanism.NIO; 
	public static boolean broadcastIpcMechanism = false; 
	public static boolean broadcastBroadcastMode = false; 
	public static String READ_THREAD_NAME = "Read Thread"; 
}
