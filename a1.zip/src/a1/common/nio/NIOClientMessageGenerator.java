package a1.common.nio;

import a1.common.FromClientToServerMessageActor;
import a1.common.InitialConfigurations;
import a1.common.InitialConfigurations.BroadcastMode;
import util.interactiveMethodInvocation.IPCMechanism;

public class NIOClientMessageGenerator implements FromClientToServerMessageActor {
	
	public NIOClientMessageGenerator() {}
	
	public String generateMessage(FromClientToServerMessageType msgType, String clientName, String secondComponent, BroadcastMode mode) {
		return 	msgType.name() 	+ DELIMETER + //type of msg 
				clientName 		+ DELIMETER + //name of the sending client
				secondComponent 	+ DELIMETER + //wildcard component encodes data based on msg type. Either command, ipcMode, or broadcastMode
				mode.name();			  		  //broadcast mode of this client
	}

}
