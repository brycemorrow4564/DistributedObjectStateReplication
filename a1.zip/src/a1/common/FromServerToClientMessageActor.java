package a1.common;

public interface FromServerToClientMessageActor {
	public enum FromServerToClientMessageType { STC_ExecuteCommand, STC_BroadcastModeChange, STC_IpcModeChange }
	public final String DELIMETER = "***";
	public final String DELIMETER_REGEX = "\\*\\*\\*";
}
