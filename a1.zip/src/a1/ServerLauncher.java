package a1;

import a1.server.SimulationServer;

public class ServerLauncher {
	public static void main(String[] args) {
		SimulationServer.main(args);
	}
}
