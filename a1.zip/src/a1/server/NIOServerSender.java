package a1.server;

import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;

import a1.common.FromClientToServerMessageActor.FromClientToServerMessageType;
import a1.common.FromServerToClientMessageActor.FromServerToClientMessageType;
import a1.common.InitialConfigurations.BroadcastMode;
import a1.common.nio.NIOServerMessageGenerator;
import a1.util.Util;
import inputport.nio.manager.NIOManagerFactory;

public class NIOServerSender {

	private SimulationServer	 		server; 
	private NIOServerMessageGenerator 	messageGenerator; 
	private NIOServerCommunicator 	communicator; 
	
	String inputCommandMatchStr = FromClientToServerMessageType.CTS_InputCommand.name(); 
	String changeBroadcastMatchStr = FromClientToServerMessageType.CTS_BroadcastModeChange.name();  
	String changeIpcMatchStr = FromClientToServerMessageType.CTS_IpcModeChange.name(); 
	
	public NIOServerSender(SimulationServer aServer, NIOServerCommunicator aCommunicator) {
		server = aServer; 
		communicator = aCommunicator;
		messageGenerator = new NIOServerMessageGenerator(); 
	}
	
	public void sendMessageToClients(FromServerToClientMessageType type, String wildcard, 
			String clientBroadcastMode, SocketChannel originChannel) {
		String msg = messageGenerator.generateMessage(type, "filler", wildcard, server.getBroadcastMode());
		ByteBuffer byteBuff =  ByteBuffer.wrap(msg.getBytes());
		ArrayList<SocketChannel> writableChannels = communicator.getWritableSockets();
		boolean isNonAtomic = clientBroadcastMode.equals("NON_ATOMIC");
		for (SocketChannel sc : writableChannels) {
			if (type == FromServerToClientMessageType.STC_ExecuteCommand && isNonAtomic && sc.equals(originChannel)) {
				System.out.println("NOT SENDING EXECUTE COMMAND TO ORIGIN CHANNEL");
				continue; 
			}
			System.out.println("Sending a message to a client " + msg);
			NIOManagerFactory.getSingleton().write(sc, byteBuff);
		}
	}

}
