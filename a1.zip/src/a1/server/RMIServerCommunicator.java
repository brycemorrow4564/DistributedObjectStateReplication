package a1.server;

import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

import a1.common.FromServerToClientMessageActor.FromServerToClientMessageType;
import a1.common.InitialConfigurations.BroadcastMode;
import a1.util.Util;
import inputport.nio.manager.NIOManagerFactory;
import test.ADistributedServerRegistrar;
import test.ADistributedSimulationRelayer;
import test.ADistributedState;
import test.DistributedServerRegistrar;
import test.DistributedState;
import test.State;
import util.interactiveMethodInvocation.IPCMechanism;

public class RMIServerCommunicator {
	
	private 	Registry 								rmiRegistry; 
	private static ADistributedState 				distState; 
	private static ADistributedServerRegistrar 		serverRegistrar;  
	private static ADistributedSimulationRelayer 		simulationRelayer; 
	
	public RMIServerCommunicator(State localState) {
		createAndExportObjects(localState);
	}

	private void createAndExportObjects(State localState) {
		distState = new ADistributedState(localState);	
		serverRegistrar = new ADistributedServerRegistrar(); 
		simulationRelayer = new ADistributedSimulationRelayer(serverRegistrar); 
		try {
			rmiRegistry = LocateRegistry.createRegistry(1099);
			UnicastRemoteObject.exportObject(serverRegistrar, 0);
			UnicastRemoteObject.exportObject(distState, 0);
			UnicastRemoteObject.exportObject(simulationRelayer, 0);
			rmiRegistry.rebind("ServerRegistrar", serverRegistrar);
			rmiRegistry.rebind("ServerState", distState);	
			rmiRegistry.rebind("ServerSimulationRelayer", simulationRelayer);	
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
	
	//Handles messages that need to be sent as a result of dynamic arguments entered server side 
	//Note that we do not handle the execution of remote simulation commands here. 
	public void sendMessageToClients(FromServerToClientMessageType type, String wildcard, String clientBroadcastMode) {
		BroadcastMode newBMode = null; 
		IPCMechanism newMech = null; 
		if (type == FromServerToClientMessageType.STC_BroadcastModeChange) {
			newBMode = Util.getBroadcastModeFromString(wildcard); 
		} else if (type == FromServerToClientMessageType.STC_IpcModeChange) {
			newMech = Util.getIpcMechanismFromString(wildcard); 
		} else {
			System.out.println("RMI Communicator trying to send invalid msg type");
			return; 
		}
		ArrayList<String> clientStubIds = serverRegistrar.getRegisteredClientStateIds();	
		for (String id: clientStubIds) {
			try {
				DistributedState clientStateStub = (DistributedState) rmiRegistry.lookup(id); 
				if (newBMode != null) {
					clientStateStub.setBroadcastMode(newBMode);
				} else {
					clientStateStub.setIpcMechanism(newMech);
				}
			} catch (Exception e) { e.printStackTrace(); }
		}
	}
	
}
