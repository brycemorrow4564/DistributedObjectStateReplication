package a1.server;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;

import a1.client.SimulationClient;
import a1.common.FromClientToServerMessageActor.FromClientToServerMessageType;
import a1.common.FromServerToClientMessageActor.FromServerToClientMessageType;
import a1.common.nio.NIOByteBufferWrapper;
import assignments.util.MiscAssignmentUtils;
import inputport.nio.manager.AScatterGatherSelectionManager;
import inputport.nio.manager.NIOManagerFactory;
import inputport.nio.manager.factories.classes.AReadingAcceptCommandFactory;
import inputport.nio.manager.factories.selectors.AcceptCommandFactorySelector;
import inputport.nio.manager.listeners.SocketChannelAcceptListener;
import inputport.nio.manager.listeners.SocketChannelCloseListener;
import inputport.nio.manager.listeners.SocketChannelConnectListener;
import inputport.nio.manager.listeners.SocketChannelReadListener;
import util.trace.port.nio.SocketChannelBound;

public class NIOServerCommunicator implements 	SocketChannelAcceptListener,
												SocketChannelReadListener, 
												SocketChannelCloseListener {
	
	private SimulationServer 						server; 
	private ArrayBlockingQueue<NIOByteBufferWrapper> 	commandQueue;
	private ServerSocketChannel 						serverSocketChannel; 
	private NIOServerSender 							serverSender; 
	private Thread 									readProcessorThread;
	private ArrayList<SocketChannel>				 	writeSockets;
	
	public NIOServerCommunicator(SimulationServer aServer, int aServerPort) {
		setFactories();
		server = aServer;  
		writeSockets = new ArrayList<SocketChannel>();
		commandQueue = new ArrayBlockingQueue<NIOByteBufferWrapper>(AScatterGatherSelectionManager.getMaxOutstandingWrites());
		serverSocketChannel = createSocketChannelAndBindToPort(aServerPort);
		makeServerConnectable(aServerPort); 
		serverSender = new NIOServerSender(server, this);
		createAndStartReadProcessorThread(); 
	}
	
	//Used when server gets local input and now needs to send a message to all clients 
	public void sendMessageToClients(FromServerToClientMessageType type, String wildcard) {
		serverSender.sendMessageToClients(type, wildcard, "filler", null);
	}
	
	//Used when we need to respond to clients 
	public void sendMessageToClients(FromServerToClientMessageType type, String wildcard, String clientBroadcastMode, SocketChannel originChannel) {
		serverSender.sendMessageToClients(type, wildcard, clientBroadcastMode, originChannel); 
	}
	
	public ArrayList<SocketChannel> getWritableSockets() {
		return writeSockets; 
	}

	protected void makeServerConnectable(int aServerPort) {
		NIOManagerFactory.getSingleton().enableListenableAccepts(serverSocketChannel, this);
	}	
	
	@Override
	public void socketChannelAccepted(ServerSocketChannel aServerSocketChannel, SocketChannel aSocketChannel) {
		NIOManagerFactory.getSingleton().addReadListener(aSocketChannel, this);	
		writeSockets.add(aSocketChannel); 
	}
	
	protected ServerSocketChannel createSocketChannelAndBindToPort(int aServerPort) {
		try {
			ServerSocketChannel retVal = ServerSocketChannel.open();
			InetSocketAddress socketAddress = new InetSocketAddress(aServerPort);
			retVal.socket().bind(socketAddress);
			SocketChannelBound.newCase(this, retVal, socketAddress);
			return retVal;
		} catch (Exception e) { 
			e.printStackTrace(); 
			return null; 
		}
	}

	@Override
	public void socketChannelRead(SocketChannel aSocketChannel, ByteBuffer aMessage, int aLength) {
		while (true) {
			try {
				System.out.println("NIO Server read from the buffer");
				ByteBuffer bufferDeepCopy = MiscAssignmentUtils.deepDuplicate(aMessage);
				NIOByteBufferWrapper wrapper = new NIOByteBufferWrapper(bufferDeepCopy, aLength, aSocketChannel); 
				commandQueue.add(wrapper);
				return; 
			} catch (IllegalStateException e) {
				System.out.println(e.getMessage());
			}	
		}
	}
	
	@Override
	public void closed(SocketChannel closedChannel, Exception theReadException) {
		writeSockets.remove(closedChannel);
	}
	
	private void createAndStartReadProcessorThread() {
		NIOServerReadProcessorRunnable runnable = new NIOServerReadProcessorRunnable(server, commandQueue); 
		readProcessorThread = new Thread(runnable); 
		readProcessorThread.setName(SimulationServer.READ_THREAD_NAME);  
		readProcessorThread.start(); 
	}
	
	protected void setFactories() {	
		AcceptCommandFactorySelector.setFactory(new AReadingAcceptCommandFactory());
	}

}
