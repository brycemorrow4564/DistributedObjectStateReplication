package a1.client;

import util.annotations.Tags;
import util.interactiveMethodInvocation.IPCMechanism;
import util.interactiveMethodInvocation.SimulationParametersController;
import util.tags.DistributedTags;
import util.trace.bean.BeanTraceUtility;
import util.trace.factories.FactoryTraceUtility;
import util.trace.port.PerformanceExperimentEnded;
import util.trace.port.PerformanceExperimentStarted;
import util.trace.port.nio.NIOTraceUtility;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;

import inputport.nio.manager.AScatterGatherSelectionManager;
import inputport.nio.manager.NIOManagerFactory;
import inputport.nio.manager.factories.classes.AReadingWritingConnectCommandFactory;
import inputport.nio.manager.factories.selectors.ConnectCommandFactorySelector;
import inputport.nio.manager.listeners.SocketChannelConnectListener;
import inputport.nio.manager.listeners.SocketChannelReadListener;
import a1.common.ASimulationParameterListener;
import a1.common.InitialConfigurations;
import a1.common.ParameterListenerActor;
import a1.common.FromClientToServerMessageActor.FromClientToServerMessageType;
import a1.common.InitialConfigurations.BroadcastMode;
import a1.common.nio.NIOByteBufferWrapper;
import a1.util.Util;
import assignments.util.MiscAssignmentUtils;
import assignments.util.inputParameters.ASimulationParametersController;
import assignments.util.inputParameters.SimulationParametersListener;
import assignments.util.mainArgs.ClientArgsProcessor;
import main.BeauAndersonFinalProject;
import stringProcessors.HalloweenCommandProcessor;
import test.State;

@Tags({DistributedTags.CLIENT})
public class SimulationClient implements PropertyChangeListener {

	private HalloweenCommandProcessor 				simulation; 
	private ClientCommunicator						communicator;
	private ClientArgumentProcessor 					argsProcessor; 
	private ArrayList<String> 						experimentLog;
	private String 									clientName;  
	private State									distState; 
	
	public SimulationClient(String aClientName) {
		clientName 		= aClientName;
		experimentLog 	= new ArrayList<String>();
	}
	
	public String getClientName() 							{ return clientName; } 
	public ClientCommunicator getCommunicator()				{ return communicator; } 
	public HalloweenCommandProcessor getSimulation()			{ return simulation; }
	
	//Distributed state getters and setters
	public boolean getBroadcastBroadcastMode() 				{ return distState.getBroadcastBroadcastMode(); } 
	public boolean getBroadcastIpcMechanism() 				{ return distState.getBroadcastIpcMechanism(); } 
	public BroadcastMode getBroadcastMode() 					{ return distState.getBroadcastMode(); }
	public IPCMechanism	getIpcMechanism() 					{ return distState.getIpcMechanism(); }	
	public void setBroadcastBroadcastMode(boolean newValue) 	{ distState.setBroadcastBroadcastMode(newValue);}
	public void setIpcMechanism(IPCMechanism mech) 			{ distState.setIpcMechanism(mech); }
	public void setBroadcastIpcMechanism(boolean newValue) 	{ distState.setBroadcastIpcMechanism(newValue); }
	public void setBroadcastMode(BroadcastMode mode) 			{ distState.setBroadcastMode(mode); 
	  														  updateSimulationConnectivity(mode); }
	

	public void addToExperimentLog(String desc) {
		experimentLog.add(desc); 
	}
	
	public void logExperimentResults() {
		int index = 0; for (String desc : experimentLog) { System.out.println(++index + "\n" + desc); }
	}
	
	public void updateSimulationConnectivity(BroadcastMode mode) {
		simulation.setConnectedToSimulation(!(mode == BroadcastMode.ATOMIC));
	}

	private ClientCommunicator initCommunicator(String aServerHost, int aServerPort) {
		return new ClientCommunicator(this, aServerHost, aServerPort, simulation, distState); 
	}
	
	private HalloweenCommandProcessor initSimulation() {
		HalloweenCommandProcessor sim = BeauAndersonFinalProject.createSimulation("", 0, 0, 450, 765, 0, 0);	
		sim.addPropertyChangeListener(this);
		sim.setConnectedToSimulation(false);
		return sim; 
	}
	
	private ClientArgumentProcessor initArgumentProcessor() {
		return new ClientArgumentProcessor(this); 
	}
	
	private State initDistributedState() {
		return new State(); 
	}
	
	private void setupTracing() {
		FactoryTraceUtility.setTracing(); BeanTraceUtility.setTracing(); NIOTraceUtility.setTracing();
	}
	
	private void initialize(String aServerHost, int aServerPort) {
		setupTracing(); 
		distState		= initDistributedState(); 
		simulation 		= initSimulation();  
		argsProcessor 	= initArgumentProcessor(); 
		communicator 	= initCommunicator(aServerHost, aServerPort); 
		argsProcessor.startProcessingArgs();
	}
	
	private static void launchClient(String aServerHost, int aServerPort, String aClientName) { 
		(new SimulationClient(aClientName)).initialize(aServerHost, aServerPort);		
	}
	
	public static void main(String[] args) {	 
		args = ClientArgsProcessor.removeEmpty(args);
		MiscAssignmentUtils.setHeadless(ClientArgsProcessor.getHeadless(args));
		launchClient(ClientArgsProcessor.getServerHost(args),
					 ClientArgsProcessor.getServerPort(args),
					 ClientArgsProcessor.getClientName(args));
	}
	
	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		if (!evt.getPropertyName().equals("InputString")) { return; }
		if (getBroadcastMode() == BroadcastMode.ATOMIC) {
			String newCommand = (String) evt.getNewValue(); 
			communicator.sendMessageToServer(FromClientToServerMessageType.CTS_InputCommand, newCommand);
		}
	}
	
}



