package a1.client;

import java.nio.ByteBuffer;
import java.util.concurrent.ArrayBlockingQueue;

import a1.common.FromServerToClientMessageActor.FromServerToClientMessageType;
import a1.common.InitialConfigurations.BroadcastMode;
import a1.common.nio.NIOByteBufferWrapper;
import a1.common.nio.NIOClientMessageParser;
import a1.util.Util;
import assignments.util.MiscAssignmentUtils;
import util.interactiveMethodInvocation.IPCMechanism;

public class NIOClientReadProcessorRunnable implements Runnable {
	
	ArrayBlockingQueue<NIOByteBufferWrapper> commandQueue;
	NIOClientMessageParser messageParser; 
	SimulationClient client; 
	
	String inputCommandMatchStr = FromServerToClientMessageType.STC_ExecuteCommand.name(); 
	String changeBroadcastMatchStr = FromServerToClientMessageType.STC_BroadcastModeChange.name(); 
	String changeIpcMatchStr = FromServerToClientMessageType.STC_IpcModeChange.name(); 
	
	public NIOClientReadProcessorRunnable(ArrayBlockingQueue commandQueue, SimulationClient client) {
		this.commandQueue = commandQueue; 
		this.messageParser = new NIOClientMessageParser(); 
		this.client = client; 
	}
	
	private void processMessage(String message) {
		//System.out.println("We read this msg from the buffer: " + message);
		String[] commandComponents = messageParser.parseMessage(message); 
		String msgType = commandComponents[0];
		String wildcardComponent = commandComponents[2];
		if (msgType.equals(inputCommandMatchStr)) { 
			String commandToExecute = wildcardComponent; 
			client.getSimulation().processCommand(commandToExecute);
		} 
		else if (msgType.equals(changeBroadcastMatchStr)) { 
			BroadcastMode newBMode = Util.getBroadcastModeFromString(wildcardComponent); 
			if (newBMode == null) { System.out.println("ERROR: Received incorrect broadcast mode change request from server"); }
			client.setBroadcastMode(newBMode); 
		} 
		else if (msgType.equals(changeIpcMatchStr)) {
			IPCMechanism newMech = Util.getIpcMechanismFromString(wildcardComponent);
			if (newMech == null) { System.out.println("ERROR: Received incorrect ipc mode change request from server"); }
			client.setIpcMechanism(newMech);
		}
		else { System.out.println("ERROR: In read processor thread. Read from buffer but msg has unknown type"); }
	}
	
	@Override
	public void run() {
		NIOByteBufferWrapper 	wrapper = null; 
		ByteBuffer 			bBuff	= null;
		while (true) {
			try   { 
				wrapper = this.commandQueue.take(); 
				bBuff 	= wrapper.getByteBuffer(); 
				processMessage(new String(bBuff.array(), bBuff.position(), wrapper.getLength())); 
			} catch (InterruptedException e) { 
				e.printStackTrace(); 
			}
		}
	}

}
