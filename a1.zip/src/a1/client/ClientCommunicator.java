package a1.client;

import java.nio.ByteBuffer;
import java.util.concurrent.ArrayBlockingQueue;

import a1.common.InitialConfigurations;
import a1.common.FromClientToServerMessageActor.FromClientToServerMessageType;
import a1.common.nio.NIOByteBufferWrapper;
import a1.common.nio.NIOClientMessageGenerator;
import inputport.nio.manager.NIOManagerFactory;
import stringProcessors.HalloweenCommandProcessor;
import test.State;
import util.interactiveMethodInvocation.IPCMechanism;

public class ClientCommunicator {

	private SimulationClient			client; 
	private NIOClientCommunicator 	nioCommunicator; 
	private RMIClientCommunicator 	rmiCommunicator; 
	
	public ClientCommunicator(SimulationClient client, String aServerHost, int aServerPort, 
			HalloweenCommandProcessor simulation, State state) {
		
		this.client 			= client; 
		nioCommunicator 		= new NIOClientCommunicator(client, aServerHost, aServerPort); 
		rmiCommunicator 		= new RMIClientCommunicator(simulation, state);
	}	
	
	public void sendMessageToServer(FromClientToServerMessageType type, String wildcard) {
		IPCMechanism mech = client.getIpcMechanism(); 
		if (mech == IPCMechanism.NIO) {
			nioCommunicator.sendMessageToServer(type, wildcard); 
		} else if (mech == IPCMechanism.RMI) {
			rmiCommunicator.sendMessageToServer(type, wildcard); 
		} else {
			System.out.println("ERROR: Unspecified IPC mechanism caused a message send failure");
		}
	}
	
}
