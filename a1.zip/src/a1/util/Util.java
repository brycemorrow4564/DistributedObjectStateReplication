package a1.util;

import a1.common.InitialConfigurations;
import a1.common.InitialConfigurations.BroadcastMode;
import util.interactiveMethodInvocation.IPCMechanism; 

public class Util {

	public static BroadcastMode getBroadcastModeFromString(String newType) {
		return 
			(newType.equals("ATOMIC") ? BroadcastMode.ATOMIC : 
			(newType.equals("NON_ATOMIC") ? BroadcastMode.NON_ATOMIC : 
			(newType.equals("LOCAL") ? BroadcastMode.LOCAL : null)));
	}
	
	public static IPCMechanism getIpcMechanismFromString(String mech) {
		return 
			(mech.equals("NIO") ? IPCMechanism.NIO : 
			(mech.equals("RMI") ? IPCMechanism.RMI : 
			(mech.equals("GIPC") ? IPCMechanism.GIPC : null)));
	}
	
	public static String[] generateRandomSimulationCommands(int numCommands) {
		String[] commands = new String[numCommands]; 
		for (int i = 0; i < numCommands; i++) {
			double randVal = Math.random(); 
			if 		(randVal < .07) 	{ commands[i] = "Take " + Util.randomIntInRange(0,5, false); } 
			else if (randVal < .15) 	{ commands[i] = "Give " + Util.randomIntInRange(0,5, false); } 
			else if (randVal < .18) 	{ commands[i] = "Undo"; } 
			else 					{ commands[i] = "Move " + Util.randomIntInRange(0,100, true) + " " + Util.randomIntInRange(0,100, true); }
		}
		return commands; 
	}
	
	public static int randomIntInRange(int lower, int upper, boolean canBeNegative) { 
		return ((int) Math.ceil(Math.random() * (upper - lower) + lower)) * 
				(canBeNegative ? (Math.random() < .5 ? 1 : -1) : 1);
	}
	
	public static String generateRandomClientId() {
		return Double.toString(Math.random() * Double.MAX_VALUE);		
	}
	
}
