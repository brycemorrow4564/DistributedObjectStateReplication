package test;

import java.rmi.Remote;
import java.rmi.RemoteException;

import a1.common.InitialConfigurations.BroadcastMode;

public interface DistributedSimulationRelayer extends Remote {
	public void sendInputCommandsToServer(String command, BroadcastMode mode, 
			String callbackClientStubRegistryId) throws RemoteException; 
}
