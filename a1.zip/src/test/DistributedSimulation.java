package test;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface DistributedSimulation extends Remote {
	public void executeSimulationCommand(String command) throws RemoteException; 
}
