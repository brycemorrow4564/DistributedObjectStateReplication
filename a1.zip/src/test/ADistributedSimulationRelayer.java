package test;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;

import a1.common.InitialConfigurations.BroadcastMode;

public class ADistributedSimulationRelayer implements DistributedSimulationRelayer {

	private static ADistributedServerRegistrar serverRegistrar;
	
	public ADistributedSimulationRelayer(ADistributedServerRegistrar serverRegistrar) {
		this.serverRegistrar = serverRegistrar; 
	}
	
	@Override
	public void sendInputCommandsToServer(String command, BroadcastMode mode, String callbackClientStubRegistryId)
			throws RemoteException {
		ArrayList<String> clientSimulationIds = serverRegistrar.getRegisteredClientSimulationIds(); 
		try {
			Registry rmiRegistry = LocateRegistry.getRegistry(1099);
			for (String id : clientSimulationIds) {
				if (!(mode == BroadcastMode.NON_ATOMIC && callbackClientStubRegistryId == id)) {
					DistributedSimulation simulationStub = (DistributedSimulation) rmiRegistry.lookup(id); 
					simulationStub.executeSimulationCommand(command);
				}
			}	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
