package test;

import java.rmi.RemoteException;
import java.util.ArrayList;

public class ADistributedServerRegistrar implements DistributedServerRegistrar {

	private static ArrayList<String> registeredClientSimulationIds; 
	private static ArrayList<String> registeredClientStateIds; 
	
	private static int clientNum = 1; 
	
	public ADistributedServerRegistrar() {
		registeredClientSimulationIds = new ArrayList<String>(); 
		registeredClientStateIds = new ArrayList<String>();
	}
	
	public ArrayList<String> getRegisteredClientSimulationIds() { return registeredClientSimulationIds; }
	public ArrayList<String> getRegisteredClientStateIds() { return registeredClientStateIds; }
	
	@Override
	public String[] registerClientsRemoteObjects()
			throws RemoteException {
		System.out.println("Registering client " + Integer.toString(clientNum) + " on the server");
		String simulationId 	= "Client" + Integer.toString(clientNum) + "Simulation"; 
		String stateId		= "Client" + Integer.toString(clientNum) + "State"; 
		clientNum += 1; 
		registeredClientSimulationIds.add(simulationId); 
		registeredClientStateIds.add(stateId);
		String[] ids = {simulationId, stateId}; 
		return ids; 
	}

}
