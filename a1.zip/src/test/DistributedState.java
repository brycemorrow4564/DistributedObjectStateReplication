package test;

import java.rmi.Remote;
import java.rmi.RemoteException;

import a1.common.InitialConfigurations;
import a1.common.InitialConfigurations.BroadcastMode;
import util.interactiveMethodInvocation.IPCMechanism;

public interface DistributedState extends Remote {

	public void setBroadcastMode(BroadcastMode mode) throws RemoteException;
	public void setIpcMechanism(IPCMechanism mech) throws RemoteException;
	
}
