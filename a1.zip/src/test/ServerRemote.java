package test;

import java.rmi.Remote;
import java.rmi.RemoteException;

import stringProcessors.HalloweenCommandProcessor;

public interface ServerRemote extends Remote {

	public void registerSimulation(String id, HalloweenCommandProcessor simulation) throws RemoteException; 
	
}
