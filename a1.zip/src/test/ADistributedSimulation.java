package test;

import java.rmi.RemoteException;

import main.BeauAndersonFinalProject;
import stringProcessors.HalloweenCommandProcessor;

public class ADistributedSimulation implements DistributedSimulation {
	
	@SuppressWarnings("unused")
	private static final long serialVersionUID = 227L;
	
	private HalloweenCommandProcessor simulation; 
	
	public ADistributedSimulation(HalloweenCommandProcessor aNonDistSimulation) {
		simulation = aNonDistSimulation; 
	}

	@Override
	public void executeSimulationCommand(String command) throws RemoteException {
		simulation.setInputString(command);
	}

}
