package a1.client;

import java.io.IOException;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.concurrent.ArrayBlockingQueue;

import a1.common.InitialConfigurations;
import a1.common.FromClientToServerMessageActor.FromClientToServerMessageType;
import a1.common.nio.NIOByteBufferWrapper;
import a1.common.nio.NIOClientMessageGenerator;
import a1.util.Util;
import assignments.util.MiscAssignmentUtils;
import inputport.nio.manager.AScatterGatherSelectionManager;
import inputport.nio.manager.NIOManagerFactory;
import inputport.nio.manager.factories.classes.AReadingWritingConnectCommandFactory;
import inputport.nio.manager.factories.selectors.ConnectCommandFactorySelector;
import inputport.nio.manager.listeners.SocketChannelConnectListener;
import inputport.nio.manager.listeners.SocketChannelReadListener;

public class NIOClientCommunicator implements SocketChannelReadListener, 
											 SocketChannelConnectListener {
	 
	private SimulationClient 						client; 
	private ArrayBlockingQueue<NIOByteBufferWrapper> 	commandQueue;
	private SocketChannel 							socketChannel; 
	private NIOClientSender 							clientSender; 
	private Thread 									readProcessorThread;
	
	public NIOClientCommunicator(SimulationClient aClient, String aServerHost, int aServerPort) {
		setFactories();
		client = aClient;  
		commandQueue = new ArrayBlockingQueue<NIOByteBufferWrapper>(AScatterGatherSelectionManager.getMaxOutstandingWrites());
		socketChannel = createSocketChannel(); 
		connectToServer(socketChannel, aServerHost, aServerPort);
		clientSender = new NIOClientSender(client, socketChannel);
		createAndStartReadProcessorThread();  
	}
	
	public void sendMessageToServer(FromClientToServerMessageType type, String wildcard) {
		switch (type) {
			case CTS_InputCommand: 			clientSender.sendSimulationCommand(wildcard); break; 
			case CTS_BroadcastModeChange: 	clientSender.sendNewBroadcastModeMessage(wildcard); break; 
			case CTS_IpcModeChange: 			clientSender.sendNewIpcModeMessage(wildcard); break; 
			default: System.out.println("ERROR: Tried to send message of unknown type to the server"); break; 
		}
	}
	
	public void socketChannelRead(SocketChannel aSocketChannel, ByteBuffer aMessage, int aLength) {
		System.out.println("READ FROM SOCKET CHANNEL ON CLIENT SIDE");
		while (true) {
			try {
				ByteBuffer bufferDeepCopy = MiscAssignmentUtils.deepDuplicate(aMessage); 
				NIOByteBufferWrapper wrapper = new NIOByteBufferWrapper(bufferDeepCopy, aLength, aSocketChannel); 
				commandQueue.add(wrapper); 	
				return; 
			} catch (IllegalStateException e) {
				System.out.println(e.getMessage());
			}	
		}
	}

	public void connected(SocketChannel aSocketChannel) {
		System.out.println("Our client is connected to the server");
		NIOManagerFactory.getSingleton().addReadListener(aSocketChannel, this);
	}
	
	public void notConnected(SocketChannel aSocketChannel, Exception e) {
		if (e != null) { e.printStackTrace(); }
	}
	
	protected SocketChannel createSocketChannel() {
		try {  
			return SocketChannel.open();
		} 
		catch (Exception e) { 
			e.printStackTrace(); 
			return null; 
		}
	}
	
	private void connectToServer(SocketChannel localChannel, String aServerHost, int aServerPort) {
		connectToSocketChannel(localChannel, aServerHost, aServerPort);
	}
	
	private void connectToSocketChannel(SocketChannel localChannel, String aServerHost, int aServerPort) {
		try {
			InetAddress aServerAddress = InetAddress.getByName(aServerHost);
			NIOManagerFactory.getSingleton().connect(localChannel, aServerAddress, aServerPort, this);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void setFactories() {
		ConnectCommandFactorySelector.setFactory(new AReadingWritingConnectCommandFactory());
	}

	private void createAndStartReadProcessorThread() {
		NIOClientReadProcessorRunnable runnable = new NIOClientReadProcessorRunnable(commandQueue, client); 
		readProcessorThread = new Thread(runnable); 
		readProcessorThread.setName(InitialConfigurations.READ_THREAD_NAME);  
		readProcessorThread.start(); 
	}
}
