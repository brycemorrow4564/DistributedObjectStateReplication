package a1.client;

import java.beans.PropertyChangeEvent;
import java.rmi.RemoteException;

import a1.common.ASimulationParameterListener;
import a1.common.FromClientToServerMessageActor;
import a1.common.ParameterListenerActor;
import a1.common.FromClientToServerMessageActor.FromClientToServerMessageType;
import a1.common.InitialConfigurations.BroadcastMode;
import a1.util.Util;
import assignments.util.inputParameters.ASimulationParametersController;
import assignments.util.inputParameters.SimulationParametersListener;
import stringProcessors.HalloweenCommandProcessor;
import util.interactiveMethodInvocation.IPCMechanism;
import util.interactiveMethodInvocation.SimulationParametersController;
import util.trace.port.PerformanceExperimentEnded;
import util.trace.port.PerformanceExperimentStarted;

public class ClientArgumentProcessor implements ParameterListenerActor {

	private SimulationClient 				client; 
	private SimulationParametersController	aSimulationParametersController; 
	
	public ClientArgumentProcessor(SimulationClient aClient) {
		client = aClient;
		setup();
	}
	
	private void setup() {
		aSimulationParametersController = new ASimulationParametersController();
		SimulationParametersListener listener = new ASimulationParameterListener(this);
		aSimulationParametersController.addSimulationParameterListener(listener);
	}
	
	public void startProcessingArgs() {
		aSimulationParametersController.processCommands();
	}

	@Override
	public void handleSimulationCommand(String newCommand) {
		newCommand = newCommand.trim(); 
		BroadcastMode bMode = client.getBroadcastMode(); 
		client.getSimulation().setInputString(newCommand);
		if (bMode == BroadcastMode.NON_ATOMIC) { 
			client.getCommunicator().sendMessageToServer(FromClientToServerMessageType.CTS_InputCommand, newCommand); 
		}
	}
	
	@Override
	public void handleBroadcastModeSwitch(String newMode) {
		newMode = newMode.trim(); 
		ClientCommunicator communicator = client.getCommunicator(); 
		BroadcastMode mode = Util.getBroadcastModeFromString(newMode); 
		if (mode == null) { return; }
		if (client.getBroadcastBroadcastMode() && (newMode.equals("ATOMIC") || newMode.equals("NON_ATOMIC"))) 	{ 
			communicator.sendMessageToServer(FromClientToServerMessageType.CTS_BroadcastModeChange, newMode); 
		} else { 
			client.setBroadcastMode(mode); 
		}
	}

	@Override
	public void handleIpcMechanismSwitch(IPCMechanism newValue) {
		ClientCommunicator communicator = client.getCommunicator(); 
		client.setIpcMechanism(newValue);
		if (client.getBroadcastIpcMechanism()) {
			communicator.sendMessageToServer(FromClientToServerMessageType.CTS_IpcModeChange, newValue.name());  
		}
	}
	

	@Override
	public void handleQuit(int aCode) {
		System.exit(aCode);
	}
	
	@Override
	public void handleBroadcastBroadcastModeSwitch(boolean newValue) {
		client.setBroadcastBroadcastMode(newValue);
	}

	@Override
	public void handleBroadcastIpcMechanismSwitch(boolean newValue) {
		client.setBroadcastIpcMechanism(newValue);
	}
	
	@Override
	public void logExperimentResults() {
		client.logExperimentResults();
	}

	@Override
	public void handleExperimentOutput() {
		int numCommands = 1000;
		String[] commands = Util.generateRandomSimulationCommands(numCommands); 
		long startTime = (long) System.nanoTime(); 
		PerformanceExperimentStarted.newCase(this, startTime, 0);
		for (String c : commands) {
			handleSimulationCommand(c); 
		}
		long endTime = (long) System.nanoTime(); 
		PerformanceExperimentEnded.newCase(this, startTime, endTime, endTime - startTime, 0); 
		String experimentDescription = "Mode: " + client.getBroadcastMode().name() + "\nDuration (seconds): " + ((endTime - startTime) / Math.pow(10, 9)); 
		client.addToExperimentLog(experimentDescription); 
		System.out.println("Our experiment in " + client.getBroadcastMode().name() + " broadcast mode lasted " + ((endTime - startTime) / Math.pow(10, 9)) + "seconds");	
	}
}
