package a1.client;

import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

import a1.common.FromClientToServerMessageActor.FromClientToServerMessageType;
import a1.common.InitialConfigurations.BroadcastMode;
import a1.util.Util;
import examples.mvc.rmi.duplex.DistributedRMICounter;
import stringProcessors.HalloweenCommandProcessor;
import test.ADistributedSimulation;
import test.ADistributedState;
import test.DistributedServerRegistrar;
import test.DistributedSimulation;
import test.DistributedSimulationRelayer;
import test.DistributedState;
import test.State;
import util.interactiveMethodInvocation.IPCMechanism;

public class RMIClientCommunicator {
	
	private static Registry rmiRegistry; 
	
	//Local objects we make available as remote stubs server side 
	private static ADistributedSimulation 		distSim; 
	private static ADistributedState 			distState;
	
	//Remote Stub References
	private static DistributedState 				serverStateStub; 
	private static DistributedSimulationRelayer 	serverSimulationStub;
	
	private static String simulationId; 
	private static String stateId; 
	
	public RMIClientCommunicator(HalloweenCommandProcessor localSimulation, State localState) {
		rmiRegistry 		= getRegistry(); 
		askServerForIdAndProvideLocalReferences(); 
		createAndExportObjects(localSimulation, localState);
		acquireRemoteStubs(); 
	}
	
	public void sendMessageToServer(FromClientToServerMessageType type, String wildcard)  {
		try {
			switch (type) {
				case CTS_InputCommand: 
					String command = wildcard; 
					BroadcastMode clientBMode = distState.getBroadcastMode(); 
					serverSimulationStub.sendInputCommandsToServer(command, clientBMode, simulationId);
					break; 
				case CTS_BroadcastModeChange: 
					BroadcastMode modeToSet = Util.getBroadcastModeFromString(wildcard);
					serverStateStub.setBroadcastMode(modeToSet);
					break; 
				case CTS_IpcModeChange:
					IPCMechanism mechToSet = Util.getIpcMechanismFromString(wildcard); 
					serverStateStub.setIpcMechanism(mechToSet);
					break; 
				default: 
					System.out.println("ERROR: Tried to send message of unknown type to the server"); 
					break; 
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
	
	private static Registry getRegistry() {
		try { return LocateRegistry.getRegistry(); } 
		catch (RemoteException e) { e.printStackTrace(); }
		return null; 
	}
	
	private static void askServerForIdAndProvideLocalReferences() {
		try {
			DistributedServerRegistrar serverRegistrarStub = (DistributedServerRegistrar) rmiRegistry.lookup("ServerRegistrar");
			String[] ids = serverRegistrarStub.registerClientsRemoteObjects(); 
			simulationId = ids[0]; 
			stateId = ids[1];
			System.out.println(simulationId.substring(0, 7) + " has been registered with the server");
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
	
	private static void createAndExportObjects(HalloweenCommandProcessor localSimulation, State localState) {
		distSim 		= new ADistributedSimulation(localSimulation); 
		distState 	= new ADistributedState(localState); 
		try {
			UnicastRemoteObject.exportObject(distSim, 0);
			UnicastRemoteObject.exportObject(distState, 0);
			rmiRegistry.rebind(simulationId, distSim);
			rmiRegistry.rebind(stateId, distState);	
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
	
	private static void acquireRemoteStubs() {
		try {
			serverStateStub 			= (DistributedState) rmiRegistry.lookup("ServerState");
			serverSimulationStub 	= (DistributedSimulationRelayer) rmiRegistry.lookup("ServerSimulationRelayer");
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}

}
