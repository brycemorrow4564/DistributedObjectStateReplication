package a1.client;

import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import a1.common.FromClientToServerMessageActor;
import a1.common.FromClientToServerMessageActor.FromClientToServerMessageType;
import a1.common.nio.NIOClientMessageGenerator;
import inputport.nio.manager.NIOManagerFactory;

public class NIOClientSender {
	
	private SimulationClient client; 
	private SocketChannel writeChannel; 
	private NIOClientMessageGenerator messageGenerator; 

	public NIOClientSender(SimulationClient aClient, SocketChannel aWriteChannel) {
		client = aClient;   
		writeChannel = aWriteChannel; 
		messageGenerator = new NIOClientMessageGenerator(); 
	}
	
	public void writeByteBufferToChannel(ByteBuffer byteBuff) {
		NIOManagerFactory.getSingleton().write(writeChannel, byteBuff);
	}
	
	public String createMessageOfType(FromClientToServerMessageType type, String wildcard) {
		return messageGenerator.generateMessage(type, client.getClientName(), wildcard, client.getBroadcastMode());
	}
	
	public void sendNewBroadcastModeMessage(String newMode) {
		String msg = createMessageOfType(FromClientToServerMessageType.CTS_BroadcastModeChange, newMode); 
		writeByteBufferToChannel(ByteBuffer.wrap(msg.getBytes()));
	}
	
	public void sendNewIpcModeMessage(String newMode) {
		String msg = createMessageOfType(FromClientToServerMessageType.CTS_IpcModeChange, newMode); 
		writeByteBufferToChannel(ByteBuffer.wrap(msg.getBytes()));
	}
	
	public void sendSimulationCommand(String command) {
		String msg = createMessageOfType(FromClientToServerMessageType.CTS_InputCommand, command); 
		writeByteBufferToChannel(ByteBuffer.wrap(msg.getBytes()));
	}
	
}
