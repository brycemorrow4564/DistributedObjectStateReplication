package a1;

import a1.client.SimulationClient;

public class ClientLauncher  {

	public static void main(String[] args) {
		SimulationClient.main(args);
	}
}
