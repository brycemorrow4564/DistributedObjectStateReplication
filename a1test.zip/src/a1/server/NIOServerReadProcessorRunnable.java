package a1.server;

import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;

import a1.common.FromClientToServerMessageActor.FromClientToServerMessageType;
import a1.common.FromServerToClientMessageActor.FromServerToClientMessageType;
import a1.common.InitialConfigurations.BroadcastMode;
import a1.common.nio.NIOByteBufferWrapper;
import a1.common.nio.NIOServerMessageGenerator;
import a1.common.nio.NIOServerMessageParser;
import a1.util.Util;
import inputport.nio.manager.AScatterGatherSelectionManager;
import inputport.nio.manager.NIOManager;
import inputport.nio.manager.NIOManagerFactory;
import assignments.util.MiscAssignmentUtils;

public class NIOServerReadProcessorRunnable implements Runnable {
	
	ArrayBlockingQueue<NIOByteBufferWrapper> 	commandQueue;
	NIOServerMessageParser					messageParser; 
	SimulationServer							server; 
	
	public NIOServerReadProcessorRunnable(SimulationServer server, ArrayBlockingQueue<NIOByteBufferWrapper> commandQueue) {
		messageParser = new NIOServerMessageParser();
		this.server = server; 
		this.commandQueue = commandQueue; 
	}
	
	public void reactToMessage(String incomingMsgType, String wildcard) {
		if (incomingMsgType.equals(FromClientToServerMessageType.CTS_InputCommand.name())) {
			//No need to change any server side parameters in this case 
		} else if (incomingMsgType.equals(FromClientToServerMessageType.CTS_BroadcastModeChange.name())) {
			server.setBroadcastMode(Util.getBroadcastModeFromString(wildcard));
		} else if (incomingMsgType.equals(FromClientToServerMessageType.CTS_IpcModeChange.name())) {
			server.setIpcMechanism(Util.getIpcMechanismFromString(wildcard));
		} else {
			System.out.println("Could not react to message of unknown type");
		}
	}
	
	public void respondToMessage(String incomingMsgTypeStr, String wildcard, String clientBroadcastMode, SocketChannel originChannel) {
		ServerCommunicator communicator = server.getCommunicator(); 
		FromServerToClientMessageType responseType = 
				incomingMsgTypeStr.equals("CTS_InputCommand") ? FromServerToClientMessageType.STC_ExecuteCommand : (
						incomingMsgTypeStr.equals("CTS_BroadcastModeChange") ? FromServerToClientMessageType.STC_BroadcastModeChange : (
								incomingMsgTypeStr.equals("CTS_IpcModeChange") ? FromServerToClientMessageType.STC_IpcModeChange : null));
		if (responseType == null) { return; }
		communicator.sendMessageToClient(responseType, wildcard, clientBroadcastMode, originChannel);
	}
	
	public void processMessage(ByteBuffer bBuff, int len, SocketChannel originChannel) {
		String message = new String(bBuff.array(), bBuff.position(), len);
		//System.out.println("We receieved a message from the client: " + message);
		String[] commandComponents = messageParser.parseMessage(message); 
		String typeStr = commandComponents[0];
		String wildcard = commandComponents[2]; //general purpose string encodes data based on msg type
		String clientBroadcastMode = commandComponents[3]; 
		reactToMessage(typeStr, wildcard); 
		respondToMessage(typeStr, wildcard, clientBroadcastMode, originChannel); 
	}
	
	@Override
	public void run() {
		NIOByteBufferWrapper wrapper = null; 
		while (true) { 		
			try { 
				wrapper = this.commandQueue.take(); 
				ByteBuffer bBuff = wrapper.getByteBuffer();
				SocketChannel originChannel = wrapper.getOriginSocketChannel(); 
				int len = wrapper.getLength(); 
				processMessage(bBuff, len, originChannel); 
			} catch (InterruptedException e) { 
				e.printStackTrace(); 
			}
		}
	}

}
