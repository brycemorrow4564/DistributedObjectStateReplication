package a1.server;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;

import a1.client.ClientArgumentProcessor;
import a1.client.ClientCommunicator;
import a1.client.NIOClientSender;
import a1.client.SimulationClient;
import a1.common.ASimulationParameterListener;
import a1.common.InitialConfigurations;
import a1.common.ParameterListenerActor;
import a1.common.InitialConfigurations.BroadcastMode;
import a1.common.nio.NIOByteBufferWrapper;
import a1.util.Util;
import assignments.util.MiscAssignmentUtils;
import assignments.util.inputParameters.ASimulationParametersController;
import assignments.util.inputParameters.SimulationParametersListener;
import assignments.util.mainArgs.ServerArgsProcessor;
import inputport.nio.manager.AScatterGatherSelectionManager;
import inputport.nio.manager.NIOManagerFactory;
import inputport.nio.manager.factories.classes.AReadingAcceptCommandFactory;
import inputport.nio.manager.factories.classes.AReadingWritingConnectCommandFactory;
import inputport.nio.manager.factories.selectors.AcceptCommandFactorySelector;
import inputport.nio.manager.factories.selectors.ConnectCommandFactorySelector;
import inputport.nio.manager.listeners.SocketChannelAcceptListener;
import inputport.nio.manager.listeners.SocketChannelReadListener;
import test.State;
import util.annotations.Tags;
import util.interactiveMethodInvocation.IPCMechanism;
import util.interactiveMethodInvocation.SimulationParametersController;
import util.tags.DistributedTags;
import util.trace.bean.BeanTraceUtility;
import util.trace.factories.FactoryTraceUtility;
import util.trace.port.nio.NIOTraceUtility;
import util.trace.port.nio.SocketChannelBound;

@Tags({DistributedTags.SERVER})
public class SimulationServer extends State {
	
	private ServerCommunicator				communicator;
	private ServerArgumentProcessor 			argsProcessor; 
	private State							distState; 
	
	public SimulationServer() {}	
	
	public void setBroadcastMode(BroadcastMode mode) 			{ distState.setBroadcastMode(mode); }
	public void setBroadcastBroadcastMode(boolean newValue) 	{ distState.setBroadcastBroadcastMode(newValue);}
	public void setIpcMechanism(IPCMechanism mech) 			{ distState.setIpcMechanism(mech); }
	public void setBroadcastIpcMechanism(boolean newValue) 	{ distState.setBroadcastIpcMechanism(newValue); }
	
	public ServerCommunicator getCommunicator() { 
		return communicator; 
	}
	
	private ServerCommunicator initCommunicator(int aServerPort) {
		return new ServerCommunicator(this, aServerPort, distState); 
	}
	
	private ServerArgumentProcessor initArgumentProcessor() {
		return new ServerArgumentProcessor(this); 
	}
	
	private State initDistributedState() {
		return new State(); 
	}

	private static void setupTracing() {
		FactoryTraceUtility.setTracing(); NIOTraceUtility.setTracing(); BeanTraceUtility.setTracing();
	}
	
	public void initialize(int aServerPort) {
		setupTracing(); 
		distState		= initDistributedState(); 
		argsProcessor 	= initArgumentProcessor();
		communicator 	= initCommunicator(aServerPort); 
		argsProcessor.startProcessingArgs();
	}
	
	public static void main(String[] args) { 
		args = ServerArgsProcessor.removeEmpty(args);
		(new SimulationServer()).initialize(ServerArgsProcessor.getServerPort(args));
	}

}
