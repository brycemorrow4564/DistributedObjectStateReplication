package a1.server;

import java.nio.channels.SocketChannel;

import a1.client.NIOClientCommunicator;
import a1.client.RMIClientCommunicator;
import a1.client.SimulationClient;
import a1.common.FromClientToServerMessageActor.FromClientToServerMessageType;
import a1.common.FromServerToClientMessageActor.FromServerToClientMessageType;
import a1.common.nio.NIOClientMessageGenerator;
import a1.common.nio.NIOServerMessageGenerator;
import test.State;
import util.interactiveMethodInvocation.IPCMechanism;

public class ServerCommunicator {
	
	private SimulationServer 		server; 
	private NIOServerCommunicator	nioCommunicator; 
	private RMIServerCommunicator 	rmiCommunicator;  

	public ServerCommunicator(SimulationServer server, int aServerPort, State state) {
		this.server 			= server; 
		nioCommunicator 		= new NIOServerCommunicator(server, aServerPort); 
		rmiCommunicator 		= new RMIServerCommunicator(state); 
	}
	
	//Used when server gets local input and now needs to send a message to all clients 
	public void sendMessageToClient(FromServerToClientMessageType type, String wildcard) {
		IPCMechanism mech = server.getIpcMechanism(); 
		if (mech == IPCMechanism.NIO) {
			nioCommunicator.sendMessageToClients(type, wildcard); 
		} else if (mech == IPCMechanism.RMI) {
			rmiCommunicator.sendMessageToClients(type, wildcard, null); 
		} else {
			System.out.println("ERROR: Unspecified IPC mechanism caused a message send failure");
		}
	}
	
	//Used when we need to respond to clients 
	public void sendMessageToClient(FromServerToClientMessageType type, String wildcard, String clientBroadcastMode, SocketChannel originChannel) {
		IPCMechanism mech = server.getIpcMechanism(); 
		if (mech == IPCMechanism.NIO) {
			nioCommunicator.sendMessageToClients(type, wildcard, clientBroadcastMode, originChannel); 
		} else if (mech == IPCMechanism.RMI) {
			rmiCommunicator.sendMessageToClients(type, wildcard, clientBroadcastMode); 
		} else {
			System.out.println("ERROR: Unspecified IPC mechanism caused a message send failure");
		}
	}
	
}
