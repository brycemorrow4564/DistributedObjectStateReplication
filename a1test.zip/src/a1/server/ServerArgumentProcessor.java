package a1.server;

import a1.client.ClientCommunicator;
import a1.client.SimulationClient;
import a1.common.ASimulationParameterListener;
import a1.common.ParameterListenerActor;
import a1.common.FromClientToServerMessageActor.FromClientToServerMessageType;
import a1.common.FromServerToClientMessageActor.FromServerToClientMessageType;
import a1.common.InitialConfigurations.BroadcastMode;
import a1.util.Util;
import assignments.util.inputParameters.ASimulationParametersController;
import assignments.util.inputParameters.SimulationParametersListener;
import util.interactiveMethodInvocation.IPCMechanism;
import util.interactiveMethodInvocation.SimulationParametersController;

public class ServerArgumentProcessor implements ParameterListenerActor {
	
	private SimulationServer 				server; 
	private SimulationParametersController	aSimulationParametersController; 

	public ServerArgumentProcessor(SimulationServer aServer) {
		server = aServer;
		setup(); 
	}
	
	private void setup() {
		aSimulationParametersController = new ASimulationParametersController();
		SimulationParametersListener listener = new ASimulationParameterListener(this);
		aSimulationParametersController.addSimulationParameterListener(listener);
	}
	
	public void startProcessingArgs() {
		aSimulationParametersController.processCommands();
	}

	@Override
	public void handleBroadcastModeSwitch(String newType) {
		ServerCommunicator communicator = server.getCommunicator(); 
		BroadcastMode mode = Util.getBroadcastModeFromString(newType); 
		if (mode == null) { return; }
		server.setBroadcastMode(mode);
		if (server.getBroadcastBroadcastMode() && (newType.equals("ATOMIC") || newType.equals("NON_ATOMIC"))) 	{ 
			communicator.sendMessageToClient(FromServerToClientMessageType.STC_BroadcastModeChange, newType);
		}
	}
	
	@Override
	public void handleIpcMechanismSwitch(IPCMechanism newValue) {
		ServerCommunicator communicator = server.getCommunicator();
		server.setIpcMechanism(newValue);
		if (server.getBroadcastIpcMechanism()) {
			communicator.sendMessageToClient(FromServerToClientMessageType.STC_IpcModeChange, newValue.name());  
		}
	}

	@Override
	public void handleQuit(int aCode) {
		System.exit(aCode);
	}
	
	@Override
	public void handleBroadcastBroadcastModeSwitch(boolean newValue) {
		server.setBroadcastBroadcastMode(newValue);
	}

	@Override
	public void handleBroadcastIpcMechanismSwitch(boolean newValue) {
		server.setBroadcastIpcMechanism(newValue);
	}
	
	//Unimplemented Methods 
	@Override
	public void handleSimulationCommand(String aCommand) {}
	@Override
	public void logExperimentResults() {}
	@Override
	public void handleExperimentOutput() {}
	
}
