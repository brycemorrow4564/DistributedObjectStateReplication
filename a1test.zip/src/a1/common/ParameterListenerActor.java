package a1.common;

import util.interactiveMethodInvocation.IPCMechanism;

public interface ParameterListenerActor {
	public void logExperimentResults();
	public void handleBroadcastModeSwitch(String newType); 
	public void handleExperimentOutput();
	public void handleSimulationCommand(String aCommand);
	public void handleQuit(int aCode);
	public void handleBroadcastBroadcastModeSwitch(boolean newValue);
	public void handleIpcMechanismSwitch(IPCMechanism newValue); 
	public void handleBroadcastIpcMechanismSwitch(boolean newValue);
}
