package a1.common.nio;

import a1.common.FromClientToServerMessageActor;

public class NIOServerMessageParser implements FromClientToServerMessageActor {

	public NIOServerMessageParser() {}
	
	public String[] parseMessage(String message) {
		String[] msgs = message.split(DELIMETER_REGEX); 
		for (int i = 0; i < msgs.length; i++) {
			msgs[i] = msgs[i].trim(); //remove trailing whitespace included to account for null parameters
		}
		return msgs; 
	}
}
