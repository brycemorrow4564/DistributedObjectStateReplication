package a1.common.nio;

import a1.common.FromServerToClientMessageActor;
import a1.common.InitialConfigurations;
import a1.common.InitialConfigurations.BroadcastMode;
import util.interactiveMethodInvocation.IPCMechanism;

public class NIOServerMessageGenerator implements FromServerToClientMessageActor {

	public NIOServerMessageGenerator() {}
	
	public String generateMessage(FromServerToClientMessageType msgType, String clientName, String secondComponent, BroadcastMode mode) {
		return 	msgType.name() 	+ DELIMETER + //type of msg 
				"Server"			+ DELIMETER + //random filler as server is sending
				secondComponent 	+ DELIMETER + //wildcard component encodes data based on msg type. Either command, ipcMode, or broadcastMode
				mode.name();
	}
}
