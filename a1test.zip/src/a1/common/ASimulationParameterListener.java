package a1.common;

import assignments.util.inputParameters.SimulationParametersListener;
import util.interactiveMethodInvocation.ConsensusAlgorithm;
import util.interactiveMethodInvocation.IPCMechanism;

public class ASimulationParameterListener implements SimulationParametersListener {
	
	private ParameterListenerActor actor; 
	
	public ASimulationParameterListener(ParameterListenerActor actor) {
		this.actor = actor;
	}
	
	@Override
	public void atomicBroadcast(boolean newValue) {
		this.actor.handleBroadcastModeSwitch(newValue ? "ATOMIC": "NON_ATOMIC"); 	
	}
	
	@Override
	public void localProcessingOnly(boolean newValue) {
		//Falls back to NON_ATOMIC when user enters local false 
		this.actor.handleBroadcastModeSwitch(newValue ? "LOCAL" : "NON_ATOMIC");			
	}
	
	@Override
	public void experimentInput() {
		this.actor.handleExperimentOutput();
	}

	@Override
	public void quit(int aCode) {
		this.actor.handleQuit(aCode); 
	}

	public void simulationCommand(String aCommand) {
		if (aCommand.equals("getExperimentResultLog")) {
			this.actor.logExperimentResults(); 
		}
		this.actor.handleSimulationCommand(aCommand); 
	}
	
	@Override public void broadcastBroadcastMode(boolean newValue) {
		this.actor.handleBroadcastBroadcastModeSwitch(newValue); 
	}
	
	@Override public void ipcMechanism(IPCMechanism newValue) {
		this.actor.handleIpcMechanismSwitch(newValue); 
	}
	
	@Override public void broadcastIPCMechanism(boolean newValue) {
		this.actor.handleBroadcastIpcMechanismSwitch(newValue);
	}
	
	@Override public void waitForBroadcastConsensus(boolean newValue) {}
	@Override public void waitForIPCMechanismConsensus(boolean newValue) {}
	@Override public void consensusAlgorithm(ConsensusAlgorithm newValue) {}

}