package a1.common;

public interface FromClientToServerMessageActor {
	public enum FromClientToServerMessageType { CTS_InputCommand, CTS_BroadcastModeChange, CTS_IpcModeChange }
	public final String DELIMETER = "***";
	public final String DELIMETER_REGEX = "\\*\\*\\*";
}
