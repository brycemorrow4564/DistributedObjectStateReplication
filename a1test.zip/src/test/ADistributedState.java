package test;

import java.rmi.RemoteException;

import a1.common.InitialConfigurations;
import a1.common.InitialConfigurations.BroadcastMode;
import util.interactiveMethodInvocation.IPCMechanism;

public class ADistributedState implements DistributedState {
	
	private State distState; 
	
	public ADistributedState(State state) {
		distState = state; 
	}
	
	public BroadcastMode getBroadcastMode() { return distState.getBroadcastMode(); }
	public IPCMechanism getIpcMechanism() { return distState.getIpcMechanism(); }

	@Override
	public void setBroadcastMode(BroadcastMode mode) throws RemoteException {
		distState.setBroadcastMode(mode);
	}

	@Override
	public void setIpcMechanism(IPCMechanism mech) throws RemoteException {
		distState.setIpcMechanism(mech);
	}

}
