package test;

import java.rmi.RemoteException;

import a1.common.InitialConfigurations;
import a1.common.InitialConfigurations.BroadcastMode;
import assignments.util.MiscAssignmentUtils;
import assignments.util.mainArgs.ClientArgsProcessor;
import util.interactiveMethodInvocation.IPCMechanism;

public class State implements InitialConfigurations {

	private BroadcastMode							broadcastMode; 
	private boolean 									broadcastBroadcastMode; 
	private IPCMechanism								ipcMechanism; 
	private boolean 									broadcastIpcMechanism; 
	
	public State() {
		setupInitialConfigurations();
	}
	
	public boolean getBroadcastBroadcastMode() 	{ return broadcastBroadcastMode; } 
	public boolean getBroadcastIpcMechanism() 	{ return broadcastIpcMechanism; } 
	public BroadcastMode getBroadcastMode() 		{ return broadcastMode; }
	public IPCMechanism	getIpcMechanism() 		{ return ipcMechanism; }
	
	public void setBroadcastMode(BroadcastMode mode)			{ broadcastMode = mode; }
	public void setBroadcastBroadcastMode(boolean newValue) 	{ broadcastBroadcastMode = newValue; }
	public void setIpcMechanism(IPCMechanism mech) 			{ ipcMechanism = mech; }
	public void setBroadcastIpcMechanism(boolean newValue) 	{ broadcastIpcMechanism = newValue; }

	@Override
	public void setupInitialConfigurations() {
		broadcastMode			= InitialConfigurations.broadcastMode; 
		ipcMechanism				= InitialConfigurations.ipcMechanism; 
		broadcastBroadcastMode 	= InitialConfigurations.broadcastBroadcastMode; 
		broadcastIpcMechanism	= InitialConfigurations.broadcastIpcMechanism; 
	}
	
}
